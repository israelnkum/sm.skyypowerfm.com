<?php $__env->startSection('content'); ?>
    <div class=" container-scroller">
        <div class="container-fluid ">
            <div class="main-panel w-100  documentation">
                <div class="content-wrapper">
                    <div class="container-fluid">
                        <div class="row mb-0 mt-5">
                            <div class="col-md-12 text-center mt-5">
                                <h3 class="text-uppercase">Select radio Station</h3>
                            </div>
                        </div>
                        <hr class="mt-0">
                        <div class="col-md-4 offset-md-4">
                            <form class="needs-validation" novalidate action="<?php echo e(route('play-commercials.index')); ?>" method="get">
                                <div class="form-group row">
                                    <div class="col-md-12">
                                        <select style="width: 100%" required name="radio_station_id" id="radio-station-id" class="form-control select-station">
                                            <option value=""></option>
                                            <?php $__currentLoopData = $radio_stations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stations): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($stations->id); ?>"><?php echo e($stations->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <div class="invalid-feedback">
                                            Select Station
                                        </div>
                                    </div>
                                    <div class="col-md-12 text-center mt-2">
                                        <button type="submit" class="btn btn-primary">Get Commercials</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="row mb-0 mt-5">
                            <div class="col-md-12 text-center mt-5">
                                <a class="btn " href="<?php echo e(route('login')); ?>">Go Back</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/scheduleMaster/resources/views/radio.blade.php ENDPATH**/ ?>