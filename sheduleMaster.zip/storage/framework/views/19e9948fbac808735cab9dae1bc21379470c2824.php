<?php $__env->startSection('content'); ?>

    <div class="wrapper">
        <div class="container">
            <!-- Page-Title -->
            <div class="row">
                <div class="col-sm-12">
                    <div class="page-title-box">
                        <div class="row ">
                            <div class="col-md-2">
                            </div>
                            <div class="col-md-6">
                                <form class="needs-validation" novalidate action="" method="get">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group row">
                                        <div class="col-md-12">
                                            <div class="input-group mb-2 mr-sm-2">
                                                <input type="text" required class="form-control" id="" placeholder="Type to search">
                                                <div class="input-group-prepend">
                                                    <button type="submit" class="btn input-group-text"><i class="mdi mdi-magnify"></i></button>
                                                </div>
                                                <div class="invalid-feedback">
                                                    Type something to search
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>

                            <div class="col-md-4 text-right">
                                <button class="btn btn-primary  waves-effect waves-light"  data-toggle="modal" data-target=".bs-example-modal-sm" type="button" >
                                    <i class="ti-user mr-1"></i> New Customer
                                </button>
                            </div>
                            <div class="modal fade bs-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
                                <div class="modal-dialog modal-sm">
                                    <form action="<?php echo e(route('customers.store')); ?>" method="post" class="needs-validation" novalidate>
                                        <?php echo csrf_field(); ?>
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title mt-0" id="mySmallModalLabel">New Customer</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="form-group row">
                                                    <div class="col-sm-12">
                                                        <label for="example-text-input">Name</label>
                                                        <input class="form-control" name="name" type="text" required id="example-text-input">
                                                        <div class="invalid-feedback">
                                                            Customer Name required
                                                        </div>
                                                    </div>

                                                    <div class="col-sm-12">
                                                        <label for="example-text-input">Email</label>
                                                        <input class="form-control" name="email" type="email" id="example-text-input">
                                                        <div class="invalid-feedback">
                                                            Type correct email
                                                        </div>
                                                    </div>

                                                    <div class="col-sm-12">
                                                        <label for="example-text-input">Phone Number</label>
                                                        <input class="form-control" name="phone_number" type="text" required id="example-text-input">
                                                        <div class="invalid-feedback">
                                                            Phone Number required
                                                        </div>
                                                    </div>

                                                    <div class="col-sm-12">
                                                        <label for="example-text-input">Company Name</label>
                                                        <input class="form-control" name="company" type="text" required id="example-text-input">
                                                        <div class="invalid-feedback">
                                                            Company Name required
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-danger waves-effect" data-dismiss="modal">Cancel</button>
                                                <button type="submit" class="btn btn-primary waves-effect waves-light">Add Customer</button>
                                            </div>
                                        </div><!-- /.modal-content -->
                                    </form>
                                </div><!-- /.modal-dialog -->
                            </div><!-- /.modal -->
                            <?php if(empty($customers)): ?>
                                <div class="col-md-12 text-center">
                                    <a href="<?php echo e(route('all-customers')); ?>">Get all Customers</a>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php if(!empty($customers)): ?>
                <div class="row">
                    <div class="col-xl-10 offset-md-1">
                        <div class="card">
                            <form action="<?php echo e(route('delete-customers')); ?>" onsubmit="return confirm('Please Confirm Delete')">
                                <?php echo csrf_field(); ?>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <h4 class="mt-0 header-title mb-4">All Customers</h4>
                                        </div>
                                        <div class="col-md-8 text-right">

                                            <button class="btn btn-danger" type="submit" id="btn-delete-customers" disabled><i class="mdi mdi-trash-can-outline"></i> Delete</button>

                                        </div>
                                    </div>
                                    <div class="table-responsive">
                                        <table id="customers_table" class="table table-hover">
                                            <thead>
                                            <tr>
                                                <th scope="col">
                                                    <div class="custom-control custom-checkbox">
                                                        <input type="checkbox" class="custom-control-input" id="checkAllItems">
                                                        <label class="custom-control-label" for="checkAllItems"></label>
                                                    </div>
                                                </th>
                                                <th scope="col">#</th>
                                                <th scope="col">Name</th>
                                                <th scope="col">Email</th>
                                                <th scope="col">Phone</th>
                                                <th scope="col">Company</th>
                                                <th scope="col">ID</th>
                                                <th scope="col">Action</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php ($i =1); ?>
                                            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td>
                                                        <div class="custom-control custom-checkbox">
                                                            <input type="checkbox" value="<?php echo e($customer->id); ?>" name="customer_ids[]" class="custom-control-input checkCustomerItem" id="check<?php echo e($customer->id); ?>">
                                                            <label class="custom-control-label" for="check<?php echo e($customer->id); ?>"></label>
                                                        </div>
                                                    </td>
                                                    <td><?php echo e($i); ?></td>
                                                    <td><?php echo e($customer->name); ?></td>
                                                    <td><?php echo e($customer->email); ?></td>
                                                    <td><?php echo e($customer->phone_number); ?></td>
                                                    <td><?php echo e($customer->company); ?></td>
                                                    <td><?php echo e($customer->id); ?></td>
                                                    <td>
                                                        <a href="#" class="btn edit-customer"> <i class="mdi mdi-pencil"></i> </a>
                                                    </td>
                                                <?php ($i++); ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>

                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="modal fade edit-customer-modal" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm">
            <form action="customers" id="edit-customer-form" method="post" class="needs-validation" novalidate>
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>

                <div class="modal-content">
                    <div class="modal-header">
                        <h6 class="modal-title mt-0" id="edit-title">New Customer</h6>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group row">
                            <div class="col-sm-12">
                                <label for="edit-name">Name</label>
                                <input class="form-control" name="name" type="text" required id="edit-name">
                                <div class="invalid-feedback">
                                    Customer Name required
                                </div>
                            </div>

                            <div class="col-sm-12">
                                <label for="edit-email">Email</label>
                                <input class="form-control" name="email" type="email" id="edit-email">
                                <div class="invalid-feedback">
                                    Type correct email
                                </div>
                            </div>

                            <div class="col-sm-12">
                                <label for="edit-phone_number">Phone Number</label>
                                <input class="form-control" name="phone_number" type="text" required id="edit-phone_number">
                                <div class="invalid-feedback">
                                    Phone Number required
                                </div>
                            </div>

                            <div class="col-sm-12">
                                <label for="edit-company">Company Name</label>
                                <input class="form-control" name="company"  type="text" required id="edit-company">
                                <div class="invalid-feedback">
                                    Company Name required
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger waves-effect" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary waves-effect waves-light">Update Info</button>
                    </div>
                </div><!-- /.modal-content -->
            </form>
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/scheduleMaster/resources/views/customers/preferences.blade.php ENDPATH**/ ?>