<?php $__env->startSection('content'); ?>
    <div class=" container-scroller">
        <div class="container-fluid ">
            <div class="main-panel w-100  documentation">
                <div class="content-wrapper">
                    <div class="container-fluid">
                        <div class="row mb-0 mt-2  ">
                            <div class="col-md-4 mt-2">
                                <h3 class="text-uppercase">Today's Commercial</h3>
                            </div>
                            <div class="col-md-4  mt-2  text-center">
                                <?php if(!empty($commercials) ): ?>
                                    <?php $__currentLoopData = $commercials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $groups): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <h3 class="text-uppercase text-danger">
                                        <?php echo e(\Carbon\Carbon::parse(strtotime($groups[0]->date))->format('D dS M Y')); ?>

                                    </h3>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-4 text-right">
                                <a class="btn " href="<?php echo e(route('login')); ?>">Login</a>
                            </div>
                        </div>
                        <hr class="mt-0">
                        <?php if(!empty($commercials)): ?>
                            <div class="row">
                                <div class="col-12 text-center">
                                    <div class="table-responsive">
                                        <table class="table table-striped table-sm table-bordered table-active">
                                            <tr>
                                                <th>Advert</th>
                                                <th>Time</th>
                                                <th>Play</th>
                                            </tr>
                                            <tbody>
                                            <?php ($i=1); ?>
                                            <?php $__currentLoopData = $commercials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $groups): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr class="bg-primary text-white">
                                                    <td colspan="3" class="text-white"><?php echo e($groups[0]->program->program_name); ?></td>
                                                </tr>
                                                <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $commercial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td ><?php echo e($commercial->advert->name); ?></td>
                                                        <td ><?php echo e($commercial->time); ?></td>
                                                        <?php if($commercial->advert->audio_file == "Upload file"): ?>
                                                            <td class="text-danger">
                                                                No Audio File
                                                            </td>
                                                        <?php else: ?>
                                                            <td class="">
                                                                <form class="" id="play-commercial-form<?php echo e($i); ?>">
                                                                    <?php echo csrf_field(); ?>
                                                                    <div class="form-group row d-none">
                                                                        <div class="col-md-4">
                                                                            <input type="hidden" name="advert_id" value="<?php echo e($commercial->advert_id); ?>">
                                                                            <input type="hidden" name="order_id" value="<?php echo e($commercial->order_id); ?>">
                                                                            <input type="hidden" name="agency_id" value="<?php echo e($commercial->agency_id); ?>">
                                                                            <input name="audio_file" id="audio_file" class="form-control" type="hidden" value="<?php echo e($commercial->advert->audio_file); ?>">
                                                                        </div>
                                                                    </div>
                                                                    <button class="btn p-0">
                                                                        <i style="font-size: 25px;" title="Play"  class="mdi mdi-play-circle"></i>
                                                                    </button>
                                                                </form>
                                                                <audio style="display: none; padding: 0" id="play<?php echo e($i); ?>" controls>
                                                                    <source src="<?php echo e(asset('public/audio_files/'.$commercial->advert->audio_file)); ?>" type="audio/mp3">
                                                                    Your browser does not support the audio element.
                                                                </audio>

                                                            </td>
                                                        <?php endif; ?>
                                                    </tr>
                                                    <?php ($i++); ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="row mt-5">
                                <div class="col-md-12 mt-5 text-center">
                                    <h2 class="text-danger font-weight-lighter mt-5">Oops! No Schedules Found</h2>
                                </div>
                                <div class="col-md-4 offset-md-4">
                                    <form class="needs-validation" novalidate action="<?php echo e(route('play-commercials.index')); ?>" method="get">
                                        <div class="form-group row">
                                            <div class="col-md-12">
                                                <select style="width: 100%" required name="radio_station_id" id="radio-station-id" class="form-control select-station">
                                                    <option value=""></option>
                                                    <?php $__currentLoopData = $radio_stations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stations): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($stations->id); ?>"><?php echo e($stations->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <div class="invalid-feedback">
                                                    Select Station
                                                </div>
                                            </div>
                                            <div class="col-md-12 text-center mt-2">
                                                <button type="submit" class="btn btn-primary">Get Commercials</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/scheduleMaster/resources/views/welcome.blade.php ENDPATH**/ ?>