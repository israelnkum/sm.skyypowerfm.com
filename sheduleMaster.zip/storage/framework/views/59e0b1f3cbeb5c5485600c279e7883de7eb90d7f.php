<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="row">
                        <div class="col-sm-6">
                            <h3>Preferences</h3>
                        </div>
                        <div class="col-md-6 text-right">
                            <button class="btn btn-primary" data-toggle="modal" data-target="#new-radio-modal">New Radio</button>
                        </div>
                    </div>
                    <div class="page-header-tab mb-1"></div>
                    <div class="row">
                        <div class="col-md-12 col-xl-12 grid-margin stretch-card">
                            <div class="">
                                <ul class="nav nav-tabs" role="tablist">
                                    <li class="nav-item">
                                        <a class="nav-link active" id="home-tab" data-toggle="tab" href="#radio-stations" role="tab" aria-controls="radio-stations" aria-selected="true">Radio Stations</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" id="profile-tab" data-toggle="tab" href="#tax" role="tab" aria-controls="tax" aria-selected="false">Tax</a>
                                    </li>
                                    
                                </ul>
                                <div class="tab-content">
                                    <div class="tab-pane fade show active" id="radio-stations" role="tabpanel" aria-labelledby="home-tab">
                                        <div class="row">
                                            
                                            <div class="col-md-12 col-xl-12 grid-margin stretch-card">
                                                <div class="card">
                                                    <div class="card-body">
                                                        <form action="<?php echo e(route('delete-radio-stations')); ?>" method="post" onsubmit="return confirm('NOTE:\nEvery Agency, Advert, Programs etc.\nassociated with this station will also be deleted! \nPlease Confirm Delete.')">
                                                            <?php echo csrf_field(); ?>
                                                            <input type="hidden" class="form-control" name="selected_radio_stations" id="selected_radio_stations">
                                                            <div class="d-flex flex-wrap justify-content-between">
                                                                <h4 class="card-title">Radio Stations</h4>
                                                                <div class="dropdown dropleft card-menu-dropdown">
                                                                    <button disabled id="btn-delete-radio" class="btn btn-link text-danger text-decoration-none text-right" type="submit">Delete</button>

                                                                    <button class="btn p-0" type="button" id="dropdown12" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                        <i class="mdi mdi-dots-vertical card-menu-btn"></i>
                                                                    </button>
                                                                    <div class="dropdown-menu" aria-labelledby="dropdown12" x-placement="left-start">
                                                                        <a class="dropdown-item" href="#">Export</a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="table-responsive">
                                                                <table class="table " id="radio-stations-table">
                                                                    <thead>
                                                                    <tr>
                                                                        <th></th>
                                                                        <th>ID</th>
                                                                        <th>Name</th>
                                                                        <th>Address</th>
                                                                        <th>Location</th>
                                                                        <th>Phone</th>
                                                                        <th>Fax</th>
                                                                        <th>Ad. Prefix</th>
                                                                        <th>Sign.</th>
                                                                        <th>Logo</th>
                                                                        <th>Edit</th>
                                                                    </tr>
                                                                    </thead>
                                                                    <tbody>

                                                                    
                                                                    <?php ($i = 1); ?>
                                                                    <?php $__currentLoopData = $radio_stations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $station): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <tr>
                                                                            <td></td>
                                                                            <td><?php echo e($station->id); ?></td>
                                                                            <td><?php echo e($station->name); ?></td>
                                                                            <td><?php echo e($station->address); ?></td>
                                                                            <td><?php echo e($station->location); ?></td>
                                                                            <td><?php echo e($station->phone_number); ?></td>
                                                                            <td><?php echo e($station->fax); ?></td>
                                                                            <td><?php echo e($station->ad_prefix); ?></td>
                                                                            <td>
                                                                                <img class="img-fluid" src="<?php echo e(asset('public/uploads/'.$station->signature)); ?>" alt="Signature">
                                                                            </td>
                                                                            <td>
                                                                                <img class="img-fluid" src="<?php echo e(asset('public/uploads/'.$station->logo)); ?>" alt="Logo">
                                                                            </td>

                                                                            <td>
                                                                                <a href="#"   class="mr-1 edit-radio-station text-muted p-2"><i class="mdi mdi-grease-pencil"></i></a>
                                                                            </td>
                                                                        </tr>
                                                                        <?php ($i+=1); ?>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="tax" role="tabpanel" aria-labelledby="profile-tab">
                                        <div class="row">
                                            
                                            <div class="col-md-12 col-xl-12 grid-margin stretch-card">
                                                <div class="card">
                                                    <div class="card-body">
                                                        <div class="table-responsive">
                                                            <form id="delete-tax-form">
                                                                <div class="d-flex flex-wrap justify-content-between">
                                                                    <h4 class="card-title">All Taxes</h4>
                                                                    <div class="dropdown dropleft card-menu-dropdown">
                                                                        <button disabled id="btn-delete-tax" class="btn btn-link text-danger text-decoration-none text-right" type="submit">Delete</button>

                                                                        <button class="btn p-0" type="button" id="dropdown12" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                            <i class="mdi mdi-dots-vertical card-menu-btn"></i>
                                                                        </button>
                                                                        <div class="dropdown-menu" aria-labelledby="dropdown12" x-placement="left-start">
                                                                            <a class="dropdown-item" href="#">Export</a>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                                <table class="table " id="taxes-table">
                                                                    <thead>
                                                                    <tr>
                                                                        <th></th>
                                                                        <th>ID</th>
                                                                        <th>#</th>
                                                                        <th>Name</th>
                                                                        <th>Value</th>
                                                                        <th>Action</th>
                                                                    </tr>
                                                                    </thead>
                                                                    <tbody>
                                                                    <?php ($i = 1); ?>
                                                                    <?php $__currentLoopData = $taxes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tax): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <tr>
                                                                            <td></td>
                                                                            <td>
                                                                                <?php echo e($tax->id); ?>

                                                                            </td>
                                                                            <td><?php echo $i; ?></td>
                                                                            <td><?php echo e($tax->name); ?></td>
                                                                            <td><?php echo e($tax->value); ?></td>
                                                                            <td>
                                                                                <a href="javascript:void(0)"  class="mr-1 edit-tax text-muted p-2"><i class="mdi mdi-grease-pencil"></i></a>
                                                                            </td>
                                                                        </tr>
                                                                        <?php ($i+=1); ?>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </tbody>
                                                                </table>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="invoice" role="tabpanel" aria-labelledby="contact-tab">
                                        Invoice
                                    </div>
                                    <div class="tab-pane fade" id="tcs" role="tabpanel" aria-labelledby="contact-tab">
                                        TC's
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <div class="modal fade p-0" id="exampleModal-4" tabindex="-1" role="dialog" aria-labelledby="ModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm p-0" role="document">
            <form id="edit-taxes-form" action="taxes" method="post" class="mb-0 needs-validation p-0" novalidate>
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>

                <div class="modal-content p-0">
                    <div class="modal-header">
                        <h5 class="modal-title" id="taxes-title">Edit Tax</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body mb-0">
                        <div class="form-group row">
                            <div class="col-md-12">
                                <label for="edit-tax-name">Tax Name:</label>
                                <input type="text" readonly name="tax_name" required class="form-control p-2" id="edit-tax-name">
                                <div class="invalid-feedback">
                                    Name required
                                </div>
                            </div>
                            <div class="col-md-12">
                                <label for="edit-tax-value">Value:</label>
                                <div class="input-group">
                                    <input required type="number" step="0.01" name="tax_value" class="form-control vat" id="edit-tax-value" min="0">
                                    <div class="input-group-prepend bg-dark">
                                        <div class="input-group-text bg-dark text-white">%</div>
                                    </div>
                                    <div class="invalid-feedback">
                                        Value required
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-success">Update</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    

    
    <div class="modal fade p-0" id="edit-radio-station-modal" tabindex="-1" role="dialog" aria-labelledby="ModalLabel" aria-hidden="true">
        <div class="modal-dialog p-0" role="document">
            <form class="needs-validation" id="edit-radio-station-form" enctype="multipart/form-data" novalidate method="post" action="radio-stations">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>

                <div class="modal-content p-0">
                    <div class="modal-header">
                        <h5 class="modal-title" id="radio-title">Edit Radio Station</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body mb-0">

                        <div class="form-group row">
                            <div class="col-md-6">
                                <label for="name" class="text-primary">Name</label>
                                <input type="text" required class="form-control p-2" id="edit-radio-name" name="name">
                                <div class="invalid-feedback">
                                    Name is required
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label for="address" class="text-primary">Address</label>
                                <input type="text" required class="form-control p-2" name="address" id="edit-radio-address">
                                <div class="invalid-feedback">
                                    Address is required
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label for="location" class="text-primary">Location</label>
                                <input type="text" class="form-control p-2" name="location" required id="edit-radio-location">
                                <div class="invalid-feedback">
                                    Location is required
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label for="phone_number" class="text-primary">Phone Number</label>
                                <input type="text" required class="form-control p-2 phone_number" name="phone_number" id="edit-radio-phone_number">
                                <div class="invalid-feedback">
                                    Phone number is required
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label for="fax" class="text-primary">Fax</label>
                                <input type="text" class="form-control p-2" id="edit-radio-fax" name="fax">
                            </div>
                            <div class="col-md-6">
                                <label for="edit-radio-prefix" class="text-primary">Advert Prefix</label>
                                <input required type="text" minlength="3" maxlength="3" placeholder="eg: SKP" class="form-control p-2" id="edit-radio-prefix" name="prefix">
                                <div class="invalid-feedback">
                                    Prefix required
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label for="signature" class="text-primary">Signature</label>
                                <input type="file" accept="image/*" class="form-control form-control-file p-2" name="signature" id="edit-radio-signature">
                            </div>
                            <div class="col-md-6">
                                <label for="logo" class="text-primary">Radio Logo</label>
                                <input type="file" accept="image/*" class="form-control p-2" name="logo" id="edit-radio-logo">
                            </div>

                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-success">Update</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    

    
    <div class="modal fade p-0" id="new-radio-modal" tabindex="-1" role="dialog" aria-labelledby="ModalLabel" aria-hidden="true">
        <div class="modal-dialog p-0" role="document">
            <form class="needs-validation" id="edit-radio-station-form" enctype="multipart/form-data" novalidate method="post" action="<?php echo e(route('radio-stations.store')); ?>">
                <?php echo csrf_field(); ?>
                <div class="modal-content p-0">
                    <div class="modal-header">
                        <h5 class="modal-title" id="radio-title">New Radio Station</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body mb-0">
                        <div class="form-group row">
                            <div class="col-md-6">
                                <label for="name" class="text-primary">Name</label>
                                <input type="text" required class="form-control p-2" id="radio-name" name="name">
                                <div class="invalid-feedback">
                                    Name is required
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label for="address" class="text-primary">Address</label>
                                <input type="text" required class="form-control p-2" name="address" id="radio-address">
                                <div class="invalid-feedback">
                                    Address is required
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label for="location" class="text-primary">Location</label>
                                <input type="text" class="form-control p-2" name="location" required id="radio-location">
                                <div class="invalid-feedback">
                                    Location is required
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label for="phone_number" class="text-primary">Phone Number</label>
                                <input type="text" required class="form-control p-2 phone_number" name="phone_number" id="edit-radio-phone_number">
                                <div class="invalid-feedback">
                                    Phone number is required
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label for="fax" class="text-primary">Fax</label>
                                <input type="text" class="form-control p-2" id="edit-radio-fax" name="fax">
                            </div>
                            <div class="col-md-6">
                                <label for="edit-radio-prefix" class="text-primary">Advert Prefix</label>
                                <input required type="text" minlength="3" maxlength="3" placeholder="eg: SKP" class="form-control p-2" id="radio-prefix" name="prefix">
                                <div class="invalid-feedback">
                                    Prefix required
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label for="signature" class="text-primary">Signature</label>
                                <input type="file" accept="image/*" class="form-control form-control-file p-2" name="signature" id="edit-radio-signature">
                            </div>
                            <div class="col-md-6">
                                <label for="logo" class="text-primary">Radio Logo</label>
                                <input type="file" accept="image/*" class="form-control p-2" name="logo" id="edit-radio-logo">
                            </div>

                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-success">Save</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/scheduleMaster/resources/views/preferences/preferences.blade.php ENDPATH**/ ?>